# NIC Port SVG Kit

`nic-ports.svg` is an editable standalone SVG containing reusable symbols `#rj45`, `#sfp`, and `#qsfp` and three demo instances.

For reusable interactive components, inline the SVG markup into the DOM (or adapt to a Rust/WASM UI SVG view); an `<img src="...">` cannot expose internal DOM state to your application.

Set the port group attributes `data-link="up|down|unknown"`, `data-rx="active|idle"`, `data-tx="active|idle"`. These are display states only. Drive them from link telemetry and counter deltas. For a DPDK-owned port, prefer LibreQoS/DPDK telemetry. Do not infer RJ45/SFP/QSFP reliably from PCI BDF alone.

Optical cage artwork is stylized, not a hardware-accurate manufacturer drawing. No JavaScript dependencies. Respect reduced motion.
