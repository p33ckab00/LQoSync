# Worker Radial Profiler V3

Changes from V2: CPU chip is now a detailed processor package with perimeter pins, inner die, circuit traces and metal frame. Expanded sectors remain curved SVG arcs, with a larger glow filter region to prevent square clipping and reduced ring-scale to preserve spacing. All existing phase labels, pinning, keyboard support, counter values, and hover interactions are retained.

Open index.html in a browser. Embedded SVG scripts may require serving via local HTTP for some browsers.

Cycle sectors remain equal-angle categories, not CPU-time shares.
